import { Component } from '@angular/core';

@Component({
    selector : "app-ironman",
    template : `
    <h1>Ironman Component</h1>
    `
})
export class IronmanComponent{

}