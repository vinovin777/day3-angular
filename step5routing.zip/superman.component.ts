import { Component } from '@angular/core';

@Component({
    template : `
    <h1>Superman Component</h1>
    `
})
export class SupermanComponent{

}