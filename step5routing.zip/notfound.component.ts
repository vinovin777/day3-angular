import { Component } from '@angular/core';

@Component({
    selector : "app-notfound",
    template : `
    <h1>Your Request did not match any result</h1>
    `
})
export class NotFoundComponent{

}