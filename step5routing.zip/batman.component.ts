import { Component } from '@angular/core';

@Component({
    template : `
    <h1>Batman Component</h1>
    `
})
export class BatmanComponent{

}