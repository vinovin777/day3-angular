import { Component } from '@angular/core';

@Component({
    template : `
    <h1>Your Request did not match any result</h1>
    `
})
export class NotFoundComponent{

}